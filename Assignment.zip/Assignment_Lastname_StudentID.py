# Tetris - DYOA Advanced at TU Graz WS 2021
# Name:       YOUR_NAME
# Student ID: YOUR_STUDENT_ID

import pygame,random,sys
from framework import BaseGame

class Circle:
    def __init__(self, game, color):
        self.color_index = None #TODO set to color index (0 or 1) passed as method parameter
        self.color = None #TODO Take correct color from circle_colors member dictionary in Basegame
        self.game = None #TODO set current game to access variables
    def swap_color(self):
        #TODO swap the color of the circle between the two possibilities (blue and yellow)
        pass

class Game(BaseGame):
    #starts the current level according to the correct set circle_count
    def start_level(self):
        #TODO get a new empty board, fill it with circles and shuffle the gameboard
        #GameLoop
        while not self.check_level_solved():
            self.draw_game_board()
            # --------------------
            # BEGIN Student Logic
            #TODO check for mouse button press, get the correct circle and swap the colors of all necessary circles
            #TODO count clicks
            # END Student Logic
            # --------------------
            self.draw_level()
            self.draw_clicks()
            pygame.display.update()

    # fills gameboard with circles in one color of your choice
    # returns nothing, just adapts self.gameboard
    def fill_gameboard(self):
        #TODO implement logic according to comments and assignment description
        pass

    # emulate clicks on the gameboard and swap the colors to make sure every level is solvable
    # returns nothing, just adapts self.gameboard
    def shuffle_gameboard(self):
        #TODO implement logic according to comments and assignment description
        pass

    # Logic to swap all circles in a diagonal pattern (X) from the clicked circle
    # returns nothing, just adapts self.gameboard
    def swap_circle_colors(self, pos):
        #TODO implement logic according to comments and assignment description
        pass
    
    # checks if the level is solved (all circles have the same color)
    # if solved return True, False otherwise
    def check_level_solved(self):
        #TODO implement logic according to comments and assignment description
        pass

# create main loop for up to 13 circles in a row
# reset clicks for each level and increase number of cicles before starting level
def main(game):
    #TODO implement logic according to comments and assignment description
    pass

#-------------------------------------------------------------------------------------
# Do not modify the code below, your implementation should be done above
#-------------------------------------------------------------------------------------
def init():
    pygame.init()
    game = Game()
    game.clicks = 0
    main(game)

if __name__ == '__main__':
    init()